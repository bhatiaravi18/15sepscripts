time ; PGPASSWORD=Tr@deEdge181 pg_restore -h 172.24.2.21 -U "diageo_alm_pgsql_prod" --dbname="DIAGEO_ALM" -j 10  -p 5432 -Fd /Datadrive/15Sep/PG_DUMPS/DIAGEO_ALM > /Datadrive/15Sep/PG_RESTORE_OUT/DIAGEO_ALM.out

