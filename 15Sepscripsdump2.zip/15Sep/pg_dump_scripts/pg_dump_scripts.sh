time ; PGPASSWORD=postgres@123 pg_dump -h 172.24.15.9 -U postgres -Fd "DIAGEO_ALM" -p 5432 -f /Datadrive/15Sep/PG_DUMPS/DIAGEO_ALM > /Datadrive/15Sep/PG_DUMP_OUT/DIAGEO_ALM.out

